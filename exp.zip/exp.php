<?php
system('calc');
?>